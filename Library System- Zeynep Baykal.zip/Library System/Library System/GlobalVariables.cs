﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_System
{
    class GlobalVariables
    {
        public static string loginRank = null;
        public static string loginUser = null;
        public static string bookname = null;
        public static int bookhistory = 7;
        public static int booknumber = 2;
    }
}
